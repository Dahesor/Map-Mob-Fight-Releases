data modify block ~ ~-1 ~ {} merge from storage map:data practice.items
playsound ui.button.click master @s ~ ~ ~ 1.7 1 1

return 1

give @s oak_sign{BlockEntityTag:{is_waxed:1b,front_text:{messages:['{"translate":"practice.all_items","clickEvent": {"action": "run_command","value": "function map:shop/new_items"}}','{"translate":"practice.all_items.get"}','""','[{"text":"[","color": "gray"},{"keybind":"key.use"},"]"]']}}}

give @p oak_sign{BlockEntityTag:{is_waxed:1b,front_text:{messages:['""','{"translate":"arrow.practice","clickEvent": {"action": "run_command","value": "/give @s tipped_arrow{custom_potion_effects:[{id:hero_of_the_village,amplifier:1b,duration:999}],HideFlags:255,display:{Name:\'{\\"translate\\": \\"arrow.practice\\"}\'}} 64"}}','""','[{"text":"[","color": "gray"},{"keybind":"key.use"},"]"]']}}}

give @p oak_sign{BlockEntityTag:{is_waxed:1b,front_text:{messages:['""','{"translate":"item.test_bow","clickEvent": {"action": "run_command","value": "/function bow"}}','""','[{"text":"[","color": "gray"},{"keybind":"key.use"},"]"]']}}}

give @p oak_sign{BlockEntityTag:{is_waxed:1b,front_text:{messages:['""','{"translate":"practice.kill_mobs","clickEvent": {"action": "run_command","value": "/function kill_mobs"}}','""','[{"text":"[","color": "gray"},{"keybind":"key.use"},"]"]']}}}

give @p oak_sign{BlockEntityTag:{is_waxed:1b,front_text:{messages:['{"translate":"practice.custom_build.1"}','{"translate":"practice.custom_build.2"}','{"translate":"practice.custom_build.3"}','""'],has_glowing_text:true}}}

setblock ~ ~ ~ oak_sign{is_waxed:1b,front_text:{messages:['{"translate":"practice.custom_build.1"}','{"translate":"practice.custom_build.2"}','{"translate":"practice.custom_build.3"}','""'],has_glowing_text:true}}