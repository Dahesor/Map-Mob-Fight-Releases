setblock 40 54 6 air
setblock -40 54 -7 air

setblock 40 54 6 oak_wall_sign[facing=east]{front_text:{messages:['""','{"translate": "practice.villager","clickEvent": {"action": "run_command","value": "/function game:run/netherite/villager/spawn"}}','""','[{"text":"[","color": "gray"},{"keybind":"key.use"},"]"]']}}
setblock -40 54 -7 oak_wall_sign[facing=west]{front_text:{messages:['""','{"translate": "practice.villager","clickEvent": {"action": "run_command","value": "/function game:run/netherite/villager/spawn"}}','""','[{"text":"[","color": "gray"},{"keybind":"key.use"},"]"]']}}