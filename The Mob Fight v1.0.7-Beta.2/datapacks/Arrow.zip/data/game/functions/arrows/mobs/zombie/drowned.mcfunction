summon drowned ~ ~ ~ {}
kill @s