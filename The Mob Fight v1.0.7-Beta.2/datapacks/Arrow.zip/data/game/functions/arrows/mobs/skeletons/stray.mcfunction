summon stray
kill