summon pillager
kill