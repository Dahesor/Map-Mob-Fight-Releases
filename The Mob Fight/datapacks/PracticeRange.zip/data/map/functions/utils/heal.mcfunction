effect clear @s
effect give @s instant_health 5 10 true
effect give @s saturation 5 10 true

return 1
give @p oak_sign{BlockEntityTag:{is_waxed:1b,front_text:{messages:['""','{"translate":"practice.heal","clickEvent": {"action": "run_command","value": "/function map:utils/heal"}}','""','[{"text":"[","color": "gray"},{"keybind":"key.use"},"]"]']}}}