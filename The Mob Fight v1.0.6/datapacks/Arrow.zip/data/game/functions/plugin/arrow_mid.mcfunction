tag @s add actived
execute unless predicate map:middle_area run return fail
data merge entity @s {damage:0.25d}
tag @s add crossed_mid