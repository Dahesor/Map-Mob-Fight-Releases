summon spider
kill @s