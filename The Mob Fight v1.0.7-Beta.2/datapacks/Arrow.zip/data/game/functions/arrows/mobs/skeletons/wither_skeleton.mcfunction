summon wither_skeleton
kill