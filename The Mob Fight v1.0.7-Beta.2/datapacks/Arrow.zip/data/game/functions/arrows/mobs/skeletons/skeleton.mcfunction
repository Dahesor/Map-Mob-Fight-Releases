summon skeleton
kill @s