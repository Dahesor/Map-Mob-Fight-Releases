return fail
scoreboard objectives add calculator dummy