# Simple UUID Converter

This is a basic library to just generate the hex UUID of an entity

## Use

> `gu:generate` - writes the UUID of the current entity to storage `gu:main out`

> `gu:convert` - converts the UUID you input as the function argument `{UUID:[I;0,1,2,3]}` and writes it to storage `gu:main out`