summon zoglin
kill