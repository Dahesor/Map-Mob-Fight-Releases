data modify storage run map.credit set value ["Dahesor"]
data modify storage run map.id set value -99b
data modify storage run map.Structures set value {type:"rotation",Pathes:["map:practice/0","map:practice/1"]}

data modify storage run map.pigMan.red set value {StructurePos:[43.0d,63.0d,26.0d],StructurePath:"map:graveyard/pig",itemPos:[43.60d,58.7d,26.50d],pigmanPos:[44.5d,64.10d,27.5d],mirror:"NONE",rotation:"NONE"}
data modify storage run map.pigMan.blue set value {StructurePos:[-42.0d,63.0d,-26.0d],StructurePath:"map:graveyard/pig",itemPos:[-42.60d,58.7d,-26.50d],pigmanPos:[-42.5d,64.10d,-24.5d],mirror:"FRONT_BACK",rotation:"NONE"}
data modify storage run map.displayName set value '{"translate":"map.practice"}'
data modify storage run map.ore.red set from storage map:data practice.ore.red
data modify storage run map.ore.blue set from storage map:data practice.ore.blue
data modify storage run map.loadCommand set value "function map:practice/load"
data modify storage run map.tickCommand set value "function map:practice/tick"
data modify storage run map.shopPos set value {red:{Pos:[50d,54d,-5d],facing:"west",Additions:[{Pos:[50d,54d,-6d],facing:"west"},{Pos:[50d,55d,-5d],facing:"west"},{Pos:[50d,55d,-6d],facing:"west"}]},blue:{Pos:[-50d,54d,4d],facing:"east",Additions:[{Pos:[-50d,54d,5d],facing:"east"},{Pos:[-50d,55d,4d],facing:"east"},{Pos:[-50d,55d,5d],facing:"east"}]}}
data modify storage run map.dirt.red set from storage map:data practice.dirt.red
data modify storage run map.dirt.blue set from storage map:data practice.dirt.blue

data modify storage run map.crystalPos set value {red:[[43.5d,48d,-4.5d],[43.5d,48d,-12.5d],[43.5d,48d,4d],[43.5d,48d,12d]],blue:[[-43.5d,48d,-4.5d],[-43.5d,48d,-12.5d],[-43.5d,48d,4d],[-43.5d,48d,12d]],BeamCenter:{red:{X:47,Y:47,Z:2},blue:{X:-47,Y:47,Z:-2}}}
data modify storage run map.spawn.red set value [49d,54.5d,0d]
data modify storage run map.spawn.blue set value [-48.0d,54.5d,0d]
data modify storage run map.netherite set value {red:[44.5d,56d,-10.5d],blue:[-43.5d,56d,10.5d]}
data modify storage run map.altar.red set value {checkPoint:[49.5d, 55.50d, -10.50d],facing:"west",extend:1b,drop:0b,blockPos:{1:{Pos:[49d, 54d, -11d],Rotation:"west"}}}
data modify storage run map.altar.blue set value {checkPoint:[-48.5d, 55.5d, 10.5d],facing:"east",extend:1b,drop:0b,blockPos:{1:{Pos:[-49d, 54d, 10d],Rotation:"east"}}}
data modify storage run map.villager set value {red:{Pos:[[39.5d,55.0d,7.5d],[32.50d,42.00d,-7.5d],[24.5d,42.00d,28.5d]]},blue:{Pos:[[-38.50d,55.00d,-7.5d],[-31.5d,42.0d,7.5d],[-23.00d,42.0d,-28.00d]]}}