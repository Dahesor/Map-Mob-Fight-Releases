summon vindicator
kill @s