summon zombie
kill @s